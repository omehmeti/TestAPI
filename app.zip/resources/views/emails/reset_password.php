<!DOCTYPE html>
<html>
<head>
	<title>Reset Password</title>
</head>
<body>
<h1>Your email: <?php echo $user->email; ?></h1>
<h1>Your new password: <?php echo $password; ?></h1>
</body>
</html>