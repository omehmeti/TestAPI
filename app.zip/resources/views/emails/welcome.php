<!DOCTYPE html>
<html>
<head>
	<title>Welcome to Pikacard/title>
</head>
<body>
<h1>Your email: <?php echo $user->email; ?></h1>
<h1>Your new password: <?php $user->email; ?></h1>
<h1>Your new password: <?php $user->phone_number; ?></h1>
</body>
</html>